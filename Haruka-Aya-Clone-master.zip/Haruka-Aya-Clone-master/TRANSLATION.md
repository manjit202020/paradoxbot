# We are glad that you want to help us translating the bot into your own language!


Kindly open this [link](https://raw.githubusercontent.com/peaktogoo/Akito_Playground/akito/English.py)
Copy it into your preferred text editor and start translating!

After you have finished, Kindly send it to [Haruka Support Group](https://t.me/HarukaAyaGroup)